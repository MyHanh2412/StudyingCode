function check(){
alert ("blue and green");
}
function test(){
    alert("grilled salmon");

}
function place(){
    
    var london = 0
    console.log('london');
   
}
function incantation(){
    alert("avada kedavra");
}

function answer(){
    document.getElementById('question').innerHTML='Quidditch';
    console.log('answer')
  
}

function sport(){

}